﻿import json
import pyodbc
import os
import logging
import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
secrets_client = boto3.client('secretsmanager')


def get_db_connection():
    """Get database connection from Secrets Manager"""
    try:
        secret_name = os.environ.get('SECRETS_MANAGER_SECRET')
        response = secrets_client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        
        connection_string = (
            f"Driver={{ODBC Driver 17 for SQL Server}};"
            f"Server={os.environ.get('RDS_ENDPOINT')};"
            f"Port={os.environ.get('RDS_PORT')};"
            f"Database={os.environ.get('RDS_DATABASE')};"
            f"UID={secret.get('username')};"
            f"PWD={secret.get('password')};"
        )
        
        conn = pyodbc.connect(connection_string)
        return conn
    except Exception as e:
        logger.exception(f"Failed to get database connection: {str(e)}")
        raise


def lambda_handler(event, context):
    """
    Execute stored procedures in SQL Server
    
    Expected event:
    {
        "procedure_name": "string",
        "parameters": {
            "param1": "value1",
            "param2": "value2"
        }
    }
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        procedure_name = event.get('procedure_name')
        parameters = event.get('parameters', {})
        
        if not procedure_name:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'procedure_name is required'})
            }
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Build parameter placeholders
        param_names = list(parameters.keys())
        param_values = [parameters[p] for p in param_names]
        param_placeholders = ','.join([f'@{p}' for p in param_names])
        
        # Build the EXEC statement
        exec_statement = f"EXEC {procedure_name}"
        if param_placeholders:
            exec_statement += f" {param_placeholders}"
        
        logger.info(f"Executing procedure: {procedure_name} with parameters: {param_names}")
        
        # Execute procedure
        cursor.execute(exec_statement, param_values)
        
        # Check if there are results to fetch
        if cursor.description:
            results = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            result_list = [dict(zip(columns, row)) for row in results]
        else:
            result_list = []
            cursor.commit()
        
        cursor.close()
        conn.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Procedure {procedure_name} executed successfully',
                'results': result_list
            })
        }
        
    except Exception as e:
        logger.exception(f"Error executing procedure: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Failed to execute procedure: {str(e)}'})
        }

